﻿<?php
require_once('../../dbConnect.php');


if (isset($_POST['delete'])) {
  $id = $_POST['Eid'];
  $sql = "UPDATE `equipment` SET `isDelete` = '1' WHERE `equipment`.`id_equipment` = '$id'";
  updateData($sql);

  $sqlUpdateSerial = "UPDATE serial_number SET serial_number.isDelete=1 WHERE serial_number.id_equipment = $id";
  updateData($sqlUpdateSerial);
}


if (isset($_POST['add'])) {
  $nameserial = $_POST['nameserial'];
  $nameEq = $_POST['nameEq'];
  $id_typeEquipment = $_POST['id_typeEquipment'];
  $detail = $_POST['detail'];
  $typeSt1 = $_POST['typeSt1'];
  $typeSt2 = $_POST['typeSt2'];
  $typeSt3 = $_POST['typeSt3'];
  $file = $_FILES['file'];
  if ($typeSt1 == 'on') {
    $st1 = 1;
  } else {
    $st1 = 0;
  }
  if ($typeSt2 == 'on') {
    $st2 = 1;
  } else {
    $st2 = 0;
  }
  if ($typeSt3 == 'on') {
    $st3 = 1;
  } else {
    $st3 = 0;
  }
  $filename = basename($_FILES['file']['name']);
  if (!file_exists("../../pic")) {
    echo ("emtry");
    mkdir("../../pic");
    move_uploaded_file($_FILES['file']['tmp_name'], "../../pic/" . $_FILES['file']['name']);
  } else {
    echo ("have path");
    move_uploaded_file($_FILES['file']['tmp_name'], "../../pic/" . $_FILES['file']['name']);
  }
  $sqlAdd = "INSERT INTO `equipment` (`id_equipment`, `name_equipment`, `e_teacher`, `e_user`, `e_staff`, `pic`, `id_typeEquipment`, `isDelete`, `detail`) 
  VALUES (NULL, '$nameEq', '$st1', '$st2', '$st3', 'pic/$filename', '$id_typeEquipment', '0','$detail')";
  addinsertData($sqlAdd);
  echo $sqlAdd;




  header("location:./name_equipment.php");
}
if (isset($_POST['edit'])) {
  $e_type = $_POST['e_type'];
  $e_name = $_POST['e_name'];
  $e_detail = $_POST['e_detail'];
  $adcheck = $_POST['adcheck'];
  $tcheck = $_POST['tcheck'];
  $ucheck = $_POST['ucheck'];
  $e_id = $_POST['e_id'];
  $type_id = $_POST['type_id'];
  if (isset($tcheck)) {
    $tcheck = 1;
  } else {
    $tcheck = 0;
  }
  if (isset($ucheck)) {
    $ucheck = 1;
  } else {
    $ucheck = 0;
  }
  if (isset($adcheck)) {
    $adcheck = 1;
  } else {
    $adcheck = 0;
  }

  $sqlroom = "UPDATE `equipment` SET `id_equipment` = '$e_id', `name_equipment` = '$e_name', `e_teacher` = '$tcheck', `e_user` = '$ucheck', `e_staff` = '$adcheck', `id_typeEquipment` = '$type_id', `detail` = '$e_detail' WHERE `equipment`.`id_equipment` = $e_id";
  echo $sqlroom;
  updateData($sqlroom);


  header("location:./name_equipment.php");
}
