<?php
header("location: index/index_teacher.php");
