<!DOCTYPE html>
<html>
<?php session_start();
$thaiprename = $_SESSION['thaiprename'];
$firstname = $_SESSION['first-name'];
$lastname = $_SESSION['last-name'];
$idcode = $_SESSION['idcode'];
$typePerson = $_SESSION['typePerson'];
$mail =  $_SESSION['mail'];
$faculty = $_SESSION['faculty'];

?>

<head>
    <?php include("../../dbConnect.php");
    $max = 0;
    $sqlTeacher = "SELECT * FROM `teacher` WHERE 1";
    $teacher = selectData($sqlTeacher);

    $sqlcart = "SELECT cart.id_cart,type_equipment.name_typeEquipment,equipment.name_equipment,cart.num_borrow FROM cart INNER JOIN user ON user.id_user = cart.id_user
    INNER JOIN equipment on equipment.id_equipment = cart.id_equipment
    INNER JOIN type_equipment ON type_equipment.id_typeEquipment = equipment.id_typeEquipment
    WHERE cart.status_accept = 'รอยืนยัน' AND user.idKU ='$idcode'";
    $cart = selectData($sqlcart);

    $sqlAddCart = "SELECT  id_typeEquipment,name_typeEquipment,id_equipment,name_equipment ,SUM(status)  AS num FROM
    (SELECT  id_typeEquipment,name_typeEquipment,id_equipment,name_equipment ,IF(status LIKE 'ไม่ได้ถูกยืม' ,status =0, status =1 ) AS status FROM
    (SELECT id_typeEquipment,name_typeEquipment,id_equipment,name_equipment, coalesce(status, 0)AS status  FROM
    (SELECT T1.id_typeEquipment ,T1.name_typeEquipment ,T1.id_equipment,T1.name_equipment,serial_number.status  FROM 
    (SELECT type_equipment.id_typeEquipment,equipment.id_equipment, type_equipment.name_typeEquipment , equipment.name_equipment 
    , equipment.e_teacher , equipment.e_user , equipment.e_staff , equipment.detail FROM equipment
    LEFT JOIN type_equipment ON equipment.id_typeEquipment = type_equipment.id_typeEquipment
    LEFT JOIN serial_number ON serial_number.id_equipment = equipment.id_equipment
    WHERE equipment.isDelete = 0 
    GROUP BY type_equipment.id_typeEquipment,equipment.id_equipment,equipment.pic , type_equipment.name_typeEquipment , equipment.name_equipment 
    , equipment.e_teacher , equipment.e_user , equipment.e_staff , equipment.detail)  AS T1 LEFT JOIN serial_number ON serial_number.id_equipment = T1.id_equipment)AS  T2) AS T3  ) AS T4
    GROUP BY name_equipment,id_typeEquipment,name_typeEquipment,id_equipment";

    $ADD_CART = selectData($sqlAddCart);

    ?>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ระบบยืม-คืนอุปกรณ์ </title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.css.map">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js"></script>
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include "../view/top-bar.php"; ?>

        <!-- Main Sidebar Container -->
        <?php include "../view/side-bar.php"; ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>การยืมอุปกรณ์</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">DataTables</li>
                            </ol>
                        </div>
                    </div>
                    <div class="row">

                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-info" style="cursor:pointer" id="addCart2">
                                <div class="inner">
                                    <h3>ตะกร้าอุปกรณ์</h3>
                                    <p>คลังอุปกรณ์ที่ต้องการยืม</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-shopping-cart"></i>
                                </div>
                                <a class="small-box-footer"> <i class="fas fa-arrow-circle"></i></a>
                            </div>
                        </div>

                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">รายชื่ออุปกรณ์ที่ยืมได้</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table class="table table-bordered table-striped" id="example1">
                                    <thead>
                                        <tr>
                                            <th>หมวดหมู่อุปกรณ์</th>
                                            <th>ชื่ออุปกรณ์</th>
                                            <th>จำนวน</th>
                                            <th>จัดการ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        </tr>
                                        <?php for ($i = 0; $i < $ADD_CART[0]['numrow']; $i++) { ?>
                                        <tr>
                                            <td><?php echo $ADD_CART[$i + 1]['name_typeEquipment'] ?></td>
                                            <td><?php echo $ADD_CART[$i + 1]['name_equipment'] ?></td>
                                            <td><?php echo $ADD_CART[$i + 1]['num'] ?></td>
                                            <td class="td-actions text-center">
                                                <!-- <a href="#" class="addCart">
                                                    <button type="button" rel="tooltip" title="ยกเลิก"
                                                        class="btn btn-black btn-link btn-sm">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </a> -->
                                                <a href="#" class="modalcart"
                                                    idEQ=<?php echo $ADD_CART[$i + 1]['id_equipment'] ?>
                                                    typeEQ=<?php echo $ADD_CART[$i + 1]['name_typeEquipment'] ?>
                                                    nameEQ=<?php echo $ADD_CART[$i + 1]['name_equipment'] ?>
                                                    num=<?php echo $ADD_CART[$i + 1]['num'] ?>>
                                                    <button type="button" class="btn btn-warning  btn-sm"
                                                        data-toggle="modal" title="เพิ่มลงตะกร้า">
                                                        <i class="fas fa-cart-arrow-down"></i>
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>หมวดหมู่อุปกรณ์</th>
                                            <th>ชื่ออุปกรณ์</th>
                                            <th>จำนวน</th>
                                            <th>จัดการ</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>

                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
                <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php include("../view/footer-bar.php"); ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <div class="modal fade" id="modalAddCart">
        <div class="modal-dialog modal-lg">
            <form class="modal-dialog modal-lg " method="POST" action='manage.php'>
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">รายการอุปกรณ์ที่ต้องการจะยืม</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body" id="addModalBody">
                        <div class="row center">
                            <div class="col-sm-12">
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                    <thead>
                                        <tr role="row">
                                            <th rowspan="1" colspan="1">หมวดหมู่อุปกรณ์</th>
                                            <th rowspan="1" colspan="1">ชื่ออุปกรณ์</th>
                                            <th rowspan="1" colspan="1">จำนวน</th>
                                            <th rowspan="1" colspan="1">จัดการ</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th rowspan="1" colspan="1">หมวดหมู่อุปกรณ์</th>
                                            <th rowspan="1" colspan="1">ชื่ออุปกรณ์</th>
                                            <th rowspan="1" colspan="1">จำนวน</th>
                                            <th rowspan="1" colspan="1">จัดการ</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php for ($i = 0; $i < $cart[0]['numrow']; $i++) { ?>
                                        <tr role="row" class="odd">

                                            <td><?php echo $cart[$i + 1]['name_typeEquipment'] ?></td>
                                            <td><?php echo $cart[$i + 1]['name_equipment'] ?></td>
                                            <td><?php echo $cart[$i + 1]['num_borrow'] ?></td>
                                            <td class="td-actions text-center">

                                                <button type="button" rel="tooltip" title=""
                                                    onclick="del('<?php echo $cart[$i + 1]['id_cart'] ?>')"
                                                    class="btn btn-black btn-link btn-sm" data-original-title="">
                                                    <i class="fas fa-window-close"></i>
                                                </button>

                                            </td>
                                            <?php } ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" name="edit">
                    <input type="hidden" name="e_id_typeEquipment" id="e_id_typeEquipment">
                    <div class="modal-footer justify-content">
                        <button type="submit" class="btn btn-primary">ยืนยัน</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">ยกเลิก</button>

                    </div>
                </div>
            </form>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modalCart">
        <div class="modal-dialog modal-lg">
            <form class="modal-dialog modal-lg " method="POST" action='manage.php'>
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">เพิ่มรายการอุปกรณ์ที่ต้องการ</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body" id="addModalBody">
                        <div class="container">
                            <div class="row mb-4">
                                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 text-right">
                                    <span>ชื่ออุปกรณ์ :</span>
                                </div>
                                <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12">
                                    <span class="bmd-form-group is-filled"><input type="text" class="form-control"
                                            id="e_nameEQ" name="e_nameEQ" value="บอร์ดArduino" maxlength="100"
                                            disabled=""></span>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 text-right">
                                    <span>หมวดหมู่อุปกรณ์ <span style="color: red">*</span> :</span>
                                </div>
                                <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12">
                                    <span class="bmd-form-group is-filled"><input type="text" class="form-control"
                                            id="e_typeEQ" name="e_typeEQ" value="อุปกรณ์iot" maxlength="100"
                                            disabled=""></span>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 text-right">
                                    <span>จำนวนอุปกรณ์ที่ต้องการ :</span>
                                </div>
                                <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12">
                                    <span class="bmd-form-group"><input type="number" id="e_num" name="e_num" min="0"
                                            max="<?php $max ?>" class="form-control" i
                                            placeholder="กรุณากรอกจำนวนอุปกรณ์"></span>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-xl-3 col-12 text-right">
                                    <span>เลือกอาจารย์ที่รับผิดชอบ :</span>
                                </div>
                                <div class="col-xl-8 col-12">อ.
                                    <select class="form-control" name="teacher" id="teacher">
                                        <?php
                                        for ($i = 0; $i < $teacher[0]['numrow']; $i++) { ?>
                                        <option> <?php echo $teacher[$i + 1]['Tfname'] ?>

                                        </option>
                                        <?php }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 text-right">
                                    <span>เหตุผลการขอยืม :</span>
                                </div>
                                <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12">
                                    <span class="bmd-form-group"><input type="text" class="form-control" id="detail"
                                            name="detail" placeholder="กรุณากรอกเหตุผลการขอยืม"></span>
                                </div>
                            </div>
                            <div class="row mb-4" style="margin:10px;">
                                <div class="col-xl-3 col-12 text-right">
                                    <span>วันที่จอง : </span>
                                </div>
                                <div class="col-xl-3 col-12">
                                    <span class="bmd-form-group is-filled"><input type="date" name="startdate"
                                            id="startdate" class="form-control" value="" maxlength="100"></span>
                                </div>
                                <div class="col-xl-3 col-12 ">
                                    <span>วันที่จะคืน : </span>
                                </div>
                                <div class="col-xl-3 col-12 ">
                                    <span class="bmd-form-group is-filled"><input type="date" class="form-control"
                                            id="enddate" name="enddate" value="" maxlength="100"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" name="addcart">
                    <input type="hidden" name="e_idEQ" id="e_idEQ">
                    <input type="hidden" name="e_nameEQ" id="e_nameEQ">
                    <input type="hidden" name="e_typeEQ" id="e_typeEQ">
                    <div class="modal-footer justify-content">
                        <button type="submit" class="btn btn-primary">ยืนยัน</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">ยกเลิก</button>

                    </div>
                </div>
            </form>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../../plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables -->
    <script src="../../plugins/datatables/jquery.dataTables.js"></script>
    <script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../dist/js/demo.js"></script>
    <!-- page script -->
    <script>
    $(function() {
        $("#example1").DataTable();
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
        });
    });
    $(function() {
        $("#example3").DataTable();
        $('#example4').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
        });
    });
    $(document).ready(function() {
        console.log("ready!");
        $("#addCart2").on('click', function() {
            $("#modalAddCart").modal('show');
        });
        $('[data-toggle="tooltip"]').tooltip();
    });

    $(".modalcart").click(function() {

        var idEQ = $(this).attr('idEQ');
        var typeEQ = $(this).attr('typeEQ');
        var nameEQ = $(this).attr('nameEQ');
        var num = $(this).attr('num');
        $max = num;
        alert(idEQ);
        alert(typeEQ);
        alert(nameEQ);
        alert($max);

        $('#e_idEQ').val(idEQ);
        $('#e_typeEQ').val(typeEQ);
        $('#e_nameEQ').val(nameEQ);
        $('#e_num').val(typeEQ);

        $("#modalCart").modal();
    });

    function del(cid) {
        alert(cid);
        $.ajax({
            type: "POST",
            data: {
                cid: cid,
                delete: "delete"
            },
            url: "./manage.php",
            async: false,

            success: function(result) {}
        });
        window.location.reload();
    }
    </script>
</body>

</html>