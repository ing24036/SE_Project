<div class="card-body mt-5">
  <footer class="text-muted">
    <br>
    <strong >Copyright &copy; 2020 <a href="#">ภาควิชาวิศวกรรมคอมพิวเตอร์</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0-pre
    </div>
  </footer>
</div>
